#!/bin/sh

rm client_read_server_write_file.txt
rm client_write_server_read_file.txt

touch client_read_server_write_file.txt
touch client_write_server_read_file.txt
