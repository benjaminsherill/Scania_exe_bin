# HPKE Example with all supported options

To build wolfSSL for this example run `./configure --enable-hpke --enable-aesgcm --enable-curve25519 --enable-ecc && make && sudo make install`

```sh
make
./hpke_test
HPKE test success
```
