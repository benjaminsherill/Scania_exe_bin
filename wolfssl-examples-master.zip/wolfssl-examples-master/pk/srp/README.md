Shows examples of how to work with SRP.

srp_gen.c show how to generate a verifier to store on the server.
srp.c shows a client and server.

The build option used for wolfSSL is

```
./configure --enable-srp
```

How to use:

```
./srp_gen wolfssl password > srp_store.h

make

./srp wolfssl password
```


