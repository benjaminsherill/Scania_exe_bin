#!/bin/sh
# param  none
# copy edmac to asp
cp ./WolfSSLDemo/target_edmac.c ./asp/target/rx72n_gcc/
cp ./WolfSSLDemo/target_edmac.h ./asp/target/rx72n_gcc/
cp ./WolfSSLDemo/target_edmac.cfg ./asp/target/rx72n_gcc/

