# Kamailio - Interrogating-CSCF Example Configuration File

Project Website:

  * https://www.kamailio.org

## Database Structure

The necessary Database files for the Interrogating-CSCF are included in this folder.

