# Kamailio OSS Fuzz Integration #

OSS-Fuzz is a free service run by Google that performs continuous fuzzing of
various open source projects.

  * https://github.com/google/oss-fuzz

Folder for Kamailio project on OSS-Fuzz:

  * https://github.com/google/oss-fuzz/tree/master/projects/kamailio

OSS-Fuzz pull request to integrate Kamailio:

  * https://github.com/google/oss-fuzz/pull/5279

Initial pull request in Kamailio, with additional details:

  * https://github.com/kamailio/kamailio/pull/2660
