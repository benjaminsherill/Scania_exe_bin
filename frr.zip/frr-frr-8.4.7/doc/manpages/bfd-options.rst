BFD SOCKET
----------

The following option controls the BFD daemon control socket location.

.. option:: --bfdctl bfd-control-socket

   Opens the BFD daemon control socket located at the pointed location.

   (default: |INSTALL_PREFIX_STATE|/bfdd.sock)
