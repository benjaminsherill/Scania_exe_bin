.. note::

   The ``libunwind`` library is optional but highly recommended, as it improves
   backtraces printed for crashes and debugging.  However, if it is not
   available for some reason, it can simply be left out without any loss of
   functionality.
