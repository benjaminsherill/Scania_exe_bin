.. _ospfd:

*****
OSPFD
*****

.. toctree::
   :maxdepth: 2

   ospf-api
   ospf-sr

