# Binary file format
Confirms to SFF-8436 specification for XFP modules.
