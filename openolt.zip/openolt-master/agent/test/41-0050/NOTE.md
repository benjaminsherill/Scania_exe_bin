# Binary file format
Confirms to SFF-8472 specification for SFP+ modules.
